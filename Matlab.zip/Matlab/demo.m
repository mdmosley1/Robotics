%% Test demo 
clear; close all; clear classes;

jc = [45 -30 30 40];
grip = 4; % in cm

L5draw_group5(jc,grip);